import React from 'react';

class Contact extends React.Component {
  render() {
    return <h2>Welcome to the Contact page of the Student Management Portal</h2>;
  }
}

export default Contact;
