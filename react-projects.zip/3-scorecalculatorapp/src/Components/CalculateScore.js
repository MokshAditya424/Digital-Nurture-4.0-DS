import React from 'react';
import '../Stylesheets/mystyle.css';

function CalculateScore() {
  const name = "John Doe";
  const school = "Green Valley High School";
  const total = 450;
  const goal = 5;

  const average = total / goal;

  return (
    <div className="score-box">
      <h2>Student Score Calculator</h2>
      <p><strong>Name:</strong> {name}</p>
      <p><strong>School:</strong> {school}</p>
      <p><strong>Total Marks:</strong> {total}</p>
      <p><strong>Goal:</strong> {goal}</p>
      <p><strong>Average Score:</strong> {average}</p>
    </div>
  );
}

export default CalculateScore;
